function getval(sel)
{
    alert("Su cita se ha guardado correctamente");
}