<!DOCTYPE html>
<html>
<head>
<script>
function pswdFail() {
  alert("Los campos deben de ser rellenados");
}
</script>
</head>

<body onload="pswdFail()">

</body>

</html>
