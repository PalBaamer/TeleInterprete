<!DOCTYPE html>
<html>
<head>
<script>
function myFunction() {
  alert("Error en la contraseña y/o usuario");
}
</script>
</head>

<body onload="myFunction()">

</body>

</html>
