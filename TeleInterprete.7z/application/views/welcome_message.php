<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="utf-8">
	<title>Teleinterprete</title>
	Las provincias que tenemos son : 
	<div id="container">
	<h1><?php
	var_dump ($provincias); ?></h1>
</body>
</html>